import traceback
import datetime

from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)
try:
    con = sqlite3.connect(database='base.db', check_same_thread=False)
    cur = con.cursor()
except:
    print('Error!')


@app.route('/')
def main():
    if cur:
        cur.execute('''SELECT * FROM notes''')
        rows = cur.fetchall()

        return render_template('main.html', nums=len(rows), rows=rows)

@app.route('/create', methods=['POST', 'GET'])
def create():
    if request.method == "POST":
        new_note = request.form['note']
        print(new_note)
        today = datetime.date.today()
        print(today)
        try:
            table_name = 'notes'
            cur.execute("INSERT INTO " + table_name + " VALUES (?,?)", (new_note, today))
            con.commit()
            return redirect("/")
        except:
            return f"Error {traceback.format_exc()}"
    else:
        return render_template('create.html')

@app.route('/delete', methods=["POST", "GET"])
def delete():
    if request.method == 'POST':
        cur.execute('''SELECT * FROM notes''')
        rows = cur.fetchall()
        delnote = request.form['note']
        print(delnote)
        try:
            table_name = 'notes'
            #cur.execute(f"DELETE FROM {table_name} WHERE note={delnote}")
            cur.execute('DELETE FROM notes WHERE note=?', (delnote,))
            con.commit()
            return redirect("/")
        except:
            return f"Error {traceback.format_exc()}"
    else:
        if cur:
            cur.execute('''SELECT * FROM notes''')
            rows = cur.fetchall()
        return render_template('delete.html', nums=len(rows), notes=rows)

@app.route('/update', methods=["POST", "GET"])
def update():
    if request.method == "POST":
        note_num = request.form['note']
        new_note = request.form['newnote']
        today = datetime.date.today()
        print(note_num)
        print(new_note)
        cur.execute('UPDATE notes set note=?, date=? WHERE note=?', (new_note,today, note_num))
        return redirect("/")
    else:
        cur.execute('''SELECT * FROM notes''')
        rows = cur.fetchall()
        return render_template("update.html", nums=len(rows), notes=rows)

if __name__ == '__main__':
    app.run()
